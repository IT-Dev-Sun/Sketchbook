export enum Space
{
	Local = 'local',
	Global = 'global'
}