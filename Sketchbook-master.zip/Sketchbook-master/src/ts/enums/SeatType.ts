export enum SeatType {
	Driver = 'driver',
	Passenger = 'passenger',
}