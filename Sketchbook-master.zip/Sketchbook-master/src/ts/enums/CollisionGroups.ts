export enum CollisionGroups {
	Default = 1,
	Characters = 2,
	TrimeshColliders = 4
}