export enum Side
{
	Left = 'left',
	Right = 'right'
}