export enum EntityType {
	Character,
	Airplane,
	Car,
	Helicopter,
	Decoration,
	System
}