import * as THREE from 'three';

export class GroundImpactData
{
	public velocity: THREE.Vector3 = new THREE.Vector3();
}